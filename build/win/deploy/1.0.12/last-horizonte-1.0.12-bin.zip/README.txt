Last.Horizonte
--------------

Last.Horizonte es un utilitario que permite agregar a tu perfil de Last.fm 
la m�sica que est�s escuchando en Radio Horizonte (Chile).

Ver:
http://code.google.com/p/last-horizonte/
http;//www.horizonte.cl/
http://www.last.fm/
